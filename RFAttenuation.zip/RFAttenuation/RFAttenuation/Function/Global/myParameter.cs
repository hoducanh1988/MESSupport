﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFAttenuation.Function.Global {
    public class myParameter {

        public enum StepMeasurement { Kit1 = 0, Kit2, First, Second, Third, Fourth, Fifth, Sixth, Seventh, Eighth, Ninth, Tenth };

    }
}
